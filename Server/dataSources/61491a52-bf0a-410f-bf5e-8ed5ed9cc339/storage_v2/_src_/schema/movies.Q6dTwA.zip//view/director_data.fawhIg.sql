create definer = root@localhost view director_data as
select `m`.`id_director`     AS `id_director`,
       `p`.`name`            AS `name`,
       sum(`m`.`imdb_score`) AS `imdb_score`,
       sum(`m`.`budget`)     AS `budget`,
       sum(`m`.`gross`)      AS `gross`
from (`movies`.`movie` `m`
         join `movies`.`person` `p` on ((`m`.`id_director` = `p`.`id_person`)))
group by `m`.`id_director`
order by `m`.`id_director`;

