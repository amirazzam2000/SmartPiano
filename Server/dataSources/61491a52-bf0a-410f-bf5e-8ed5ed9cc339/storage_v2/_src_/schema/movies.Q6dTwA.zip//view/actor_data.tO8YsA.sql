create definer = root@localhost view actor_data as
select `movies`.`person`.`id_person`      AS `id_person`,
       `movies`.`person`.`name`           AS `name`,
       avg(`movies`.`movie`.`imdb_score`) AS `avg_imdb_score`,
       avg(`movies`.`movie`.`gross`)      AS `avg_gross`,
       avg(`movies`.`movie`.`budget`)     AS `avg_budget`
from ((`movies`.`movie` join `movies`.`actor_movie` `am` on ((`movies`.`movie`.`id_movie` = `am`.`id_movie`)))
         join `movies`.`person`
              on ((`am`.`id_actor` = `movies`.`person`.`id_person`)))
where (`movies`.`movie`.`movie_facebook_likes` <
       `movies`.`person`.`facebook_likes`)
group by `am`.`id_actor`;

